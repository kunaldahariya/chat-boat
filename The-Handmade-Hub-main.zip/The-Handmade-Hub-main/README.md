# The Handmade Hub

Handmade Hub is an e-commerce platform dedicated to promoting Indian handmade businesses. Our mission is to showcase the rich craftsmanship of Indian artisans, providing a platform for them to reach a wider audience.


## Features

- Browse and purchase a diverse range of handcrafted products.
- Support local artisans and their traditional   craftsmanship.

- Secure and easy-to-use checkout process.

- User-friendly interface for a seamless shopping experience.


